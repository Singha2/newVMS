package vms.practice;

public class Factorial {
    public static void main(String[] args) {
        int number = 6;
        int factorialValue = recursive(number);
        System.out.println("Factorial value is " + factorialValue);
    }

    private static int factorial(int number) {

        int factValue = number;
        int previous = number;
        while(previous > 1 ){
            previous = previous - 1;
            factValue = factValue * previous;
        }

        return factValue;
    }

    private static int recursive(int number){
        if(number == 0)
            return 1;
        return number * recursive(number -1);
    }
}
