package vms.practice;

import java.util.ArrayList;
import java.util.List;

public class ReverseList {
    public static void main (String args[]){

        List<String> students = new ArrayList();
        students.add("Amit");
        students.add("Kunal");
        students.add("Abhishek");
        students.add("Ruchita");

        List<String> inverse = new ArrayList<>();

        int studentsSize = students.size();
        for(int k = studentsSize-1 ; k >= 0; k--){
            inverse.add(students.get(k));
        }

        for(String student : inverse){
            System.out.println(student);
        }

    }
}
