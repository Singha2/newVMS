package vms.practice;

import java.util.ArrayList;
import java.util.List;

public class FindLargestElement {
    public static void main(String[] args) {

        List<Integer> weights = new ArrayList<>();
        weights.add(7);
        weights.add(10);
        weights.add(3);
        weights.add(27);
        weights.add(8);
        weights.add(17);

        int maxWeight = 0;

        for(int i = 0; i < weights.size(); i++){
            if(weights.get(i) > maxWeight){
                maxWeight = weights.get(i);
            }
        }
        System.out.println(maxWeight);
    }
}
