package vms.practice;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class ComparatorExample {
    public static void main(String[] args) {
        Emp emp1 = new Emp("Amit Singh", 1000, 25);
        Emp emp2 = new Emp("Kunal Krishna", 2000, 26);
        Emp emp3 = new Emp("Abhishek Roy", 3000, 27);

        List<Emp> employees = new ArrayList<>();
        employees.add(emp1);
        employees.add(emp2);
        employees.add(emp3);

        Collections.sort(employees, new SalaryComparator());

        System.out.println(employees);
    }
}
