package vms.practice;

public class CheckPalindrome {
    public static void main(String[] args) {
        int number = 7894987;
        boolean isPalindrome = isPalindromeNumber(number);
        System.out.println("The number " + number +" is " + isPalindrome);
    }

    public static boolean isPalindromeNumber(int number) {

        int temp = number;
        int rev = 0 ;
        while(temp > 0){
            int ld = temp % 10;
            rev = rev * 10 + ld;
            temp = temp/10;
        }
        if (rev == number) return true;
        return false;
    }
}
