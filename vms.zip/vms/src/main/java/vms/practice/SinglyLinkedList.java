package vms.practice;

public class SinglyLinkedList {
    class Node {
        int data;
        Node next;

        public Node(int data){
            this.data = data;
            this.next = null;
        }
    }

    private Node head = null;
    private Node tail = null;

    public void add(int data){
        Node current = new Node(data);
        if(this.head == null){
            head = current;
            tail = current;
            return;
        }
        tail.next = current;
        tail = current;
    }

    public void display(){
        Node current = head;
        if(current == null){
            System.out.println("List is empty");
            return;
        }
        while(current.next !=null ){
            System.out.println(current.data);
            current = current.next;
        }
    }

    public int sizeOfList(){
        Node current = head;
        int size = 0;
        if(current == null){
            return size;
        }

        while(current.next !=null ){
            current = current.next;
            size++;
        }
        return size;
    }
}
