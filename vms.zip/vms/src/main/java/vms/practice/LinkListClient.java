package vms.practice;

public class LinkListClient {
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();

        list.add(100);
        list.add(200);
        list.add(700);
        list.add(400);

        list.display();
        System.out.println("Size of List " + list.sizeOfList());

    }
}
