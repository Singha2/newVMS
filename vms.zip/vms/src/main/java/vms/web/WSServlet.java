package vms.web;

import vms.webservice.core.RequestHandler;
import vms.webservice.core.WebServiceLoader;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


public class WSServlet extends HttpServlet {
    public WSServlet() {
        super();
    }
    @Override
    public void service(HttpServletRequest req, HttpServletResponse res) throws IOException {
        System.out.println("This in my node");
        RequestHandler handler = WebServiceLoader.getINSTANCE().getRequestHandler();
        handler.doHandle(req, res);

    }
}
