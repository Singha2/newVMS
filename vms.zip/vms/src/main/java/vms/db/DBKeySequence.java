package vms.db;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.FindOneAndUpdateOptions;
import com.mongodb.client.model.ReturnDocument;
import org.bson.Document;
import vms.entity.BaseEntity;
import vms.entity.Counter;

public class DBKeySequence {

    public Object getNextSequence(BaseEntity entity){

        BaseDataProvider dbProvider = new BaseDataProvider();
        BaseEntity counter = new Counter();
        MongoCollection<Document> counters = dbProvider.getCollection(counter);

        BasicDBObject find = new BasicDBObject();
        find.put("_id", entity.getEntityId());
        BasicDBObject update = new BasicDBObject();
        update.put("$inc", new BasicDBObject("seq", 1));
        FindOneAndUpdateOptions options = new FindOneAndUpdateOptions();
        Document obj = counters.findOneAndUpdate(find, update, options.returnDocument(ReturnDocument.AFTER));

        return obj.get("seq");

    }
}
