package vms.db;

import org.bson.Document;
import vms.db.dataprovider.CompanyDataProvider;
import vms.entity.Company;



public class DataSource {
    public static void main (String args[]){
        CompanyDataProvider dataProvider = CompanyDataProvider.getInstance();
        Company company = dataProvider.newCompanyInstance();
        company.setName("vertisage labs pvt ltd");
        company.setShortname("vertisage");
        company.setType("Client");
        if(dataProvider.saveCompany(company)){
            Document result = dataProvider.getCompanyByShortName("vertisage");
            System.out.println(result.toJson());
        }

    }
}
