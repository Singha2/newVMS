package vms.db.dataprovider;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import org.bson.Document;
import vms.db.BaseDataProvider;
import vms.db.DBKeySequence;
import vms.entity.Company;

public class CompanyDataProvider extends BaseDataProvider {

    private final DBKeySequence sequencer = new DBKeySequence();

    public static CompanyDataProvider getInstance(){
        return new CompanyDataProvider();
    }

    private Company getRawInstance(){
        Company company = new Company();
        return company;
    }

    public boolean saveCompany(Company entity){
        MongoCollection<Document> collection = this.getCollection(entity);
        collection.insertOne(entity.getCompanyDocument());
        return entity.getCompanyDocument().containsKey("_id");
    }

    public Document getCompanyByShortName(final String name){
        Company company = getRawInstance();
        Document result = null;
        MongoCollection<Document> collection = this.getCollection(company);
        BasicDBObject whereQuery = new BasicDBObject();
        whereQuery.put("shortname", name);

        try( MongoCursor<Document> cursor = collection.find(whereQuery).iterator()) {
            while (cursor.hasNext()) {
                result = cursor.next();
            }
        }
        return result;
    }

    public Company newCompanyInstance(){
        Company company = this.getRawInstance();
        Object companyId = sequencer.getNextSequence(company);
        company.setCompanyid(Long.parseLong(String.valueOf(companyId)));
        return company;
    }
}
