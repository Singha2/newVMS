package vms.db;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import vms.entity.BaseEntity;

public class BaseDataProvider {

    // load this from application property file
    // Remove hard coding from class
    public MongoCollection<Document> getCollection(BaseEntity entity){
        MongoClient client = new MongoClient( "localhost", 27017);
        MongoDatabase database = client.getDatabase("vms");
        MongoCollection<Document> collection = database.getCollection(entity.getCollectionName());
        return collection;
    }
}
