package vms.company.endpoint;

import org.bson.Document;
import vms.db.dataprovider.CompanyDataProvider;
import vms.dto.CompanyDTO;
import vms.dto.ResponseDTO;
import vms.webservice.core.EndPoint;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EndPoint_Company_GET extends EndPoint {
    @Override
    public ResponseDTO process(HttpServletRequest request, HttpServletResponse resp) {

        String compShortName = request.getParameter("shortname");
        CompanyDataProvider dataProvider = CompanyDataProvider.getInstance();
        Document result = dataProvider.getCompanyByShortName(compShortName.toLowerCase());
        CompanyDTO dto = new CompanyDTO();
        dto.setName(result.get("name").toString());
        dto.setShortname(result.get("shortname").toString());
        return dto;

    }
}
