package vms.company.endpoint;

import org.bson.Document;
import vms.db.dataprovider.CompanyDataProvider;
import vms.dto.ResponseDTO;
import vms.entity.Company;
import vms.webservice.core.EndPoint;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EndPoint_Company_POST extends EndPoint {
    @Override
    public ResponseDTO process(HttpServletRequest request, HttpServletResponse resp) {
        String companyName = request.getParameter("name");
        String shortName = request.getParameter("shortname");
        String type = request.getParameter("type");
        CompanyDataProvider dataProvider = CompanyDataProvider.getInstance();
        Company company = dataProvider.newCompanyInstance();
        company.setName(companyName);
        company.setShortname(shortName.toLowerCase());
        company.setType(type);
        ResponseDTO response = null;
        if(dataProvider.saveCompany(company)){
            Document result = dataProvider.getCompanyByShortName(shortName);
            response = new ResponseDTO("created");
        }
        resp.setStatus(201);
        return  response;
    }
}
