package vms.entity;

import org.bson.Document;

public class Company implements BaseEntity {


    private Long companyid;
    private String name;
    private String shortname;
    private String type;
    private String parentCompId;
    private Document companyDocument;


    public Company() {
        companyDocument = new Document();
    }

    @Override
    public String getEntityId() {
        return "companyid";
    }

    @Override
    public String getCollectionName() {
        return "company";
    }

    public Long getCompanyid() {
        return companyid;
    }

    public void setCompanyid(Long companyid) {
        this.companyid = companyid;
        companyDocument.append("companyid", companyid);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        companyDocument.append("name", name);
    }

    public String getShortname() {
        return shortname;
    }

    public void setShortname(String shortname) {
        this.shortname = shortname;
        companyDocument.append("shortname", shortname);
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
        companyDocument.append("type", type);
    }

    public String getParentCompId() {
        return parentCompId;
    }

    public void setParentCompId(String parentCompId) {
        companyDocument.append("parentcompid", parentCompId);
        this.parentCompId = parentCompId;
    }

    public Document getCompanyDocument(){
        return companyDocument;
    }

}
