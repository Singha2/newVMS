package vms.entity;

public class Credential implements BaseEntity{

    private String linkedId;
    private String linkedType;
    private String secret;
    private String secretKey;


    public String getLinkedId() {
        return linkedId;
    }

    public void setLinkedId(String linkedId) {
        this.linkedId = linkedId;
    }

    public String getLinkedType() {
        return linkedType;
    }

    public void setLinkedType(String linkedType) {
        this.linkedType = linkedType;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    @Override
    public String getEntityId() {
        return null;
    }

    @Override
    public String getCollectionName() {
        return "credential";
    }
}
