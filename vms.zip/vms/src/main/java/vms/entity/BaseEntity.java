package vms.entity;

public interface BaseEntity {
    String getEntityId();
    String getCollectionName();
}
