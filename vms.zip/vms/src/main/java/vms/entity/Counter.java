package vms.entity;

public class Counter implements BaseEntity{
    @Override
    public String getEntityId() {
        return null;
    }

    @Override
    public String getCollectionName() {
        return "counters";
    }
}
