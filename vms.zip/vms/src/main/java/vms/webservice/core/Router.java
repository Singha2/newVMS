package vms.webservice.core;

import vms.company.endpoint.EndPoint_Company_GET;
import vms.company.endpoint.EndPoint_Company_POST;

public class Router extends BaseRouter{


    public Router() {
        registerRoutes();
    }

    void registerRoutes(){
         get("/public/company", new EndPoint_Company_GET());
         post("/public/company", new EndPoint_Company_POST());
    }

}
