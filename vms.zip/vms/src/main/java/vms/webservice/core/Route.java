package vms.webservice.core;

public class Route {

    public Route(String urlPattern, HttpMethods httpMethods, EndPoint endPoint) {
        this.urlPattern = urlPattern;
        this.httpMethods = httpMethods;
        this.endPoint = endPoint;
    }

    public String getUrlPattern() {
        return urlPattern;
    }

    public HttpMethods getHttpMethods() {
        return httpMethods;
    }

    public String getEndPointKey(){
        return this.httpMethods + "|" + this.urlPattern;
    }


    public EndPoint getEndPoint() {
        return endPoint;
    }

    private String urlPattern;
    private HttpMethods httpMethods;
    private EndPoint endPoint;
}
