package vms.webservice.core;

import vms.dto.ResponseDTO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class EndPoint {

    public abstract ResponseDTO process(HttpServletRequest request, HttpServletResponse resp);
}
