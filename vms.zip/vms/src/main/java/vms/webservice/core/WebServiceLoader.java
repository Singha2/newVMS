package vms.webservice.core;

public class WebServiceLoader {
    private static WebServiceLoader INSTANCE = new WebServiceLoader();
    private WebServiceConfig config;

    private WebServiceLoader(){
        initializeWebServiceConfig();
    }

    public static WebServiceLoader getINSTANCE(){
        return INSTANCE;
    }

    private void initializeWebServiceConfig(){
        config = new WebServiceConfig();
    }

    public RequestHandler getRequestHandler(){
        return new RequestHandler(this.config);
    }


}
