package vms.webservice.core;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public abstract class BaseRouter {
    private static String BASE_PATH = "/vms/rest";
    protected Map<String, Route> routes = new HashMap<>();

    protected void doRegisterRoute(String urlPattern, HttpMethods httpMethods, EndPoint endPoint) {
        Route registeredRoute = new Route(urlPattern, httpMethods, endPoint);
        routes.put(registeredRoute.getEndPointKey(), registeredRoute );
    }

    public Map<String, Route> provideAllRoutes(){
        return Collections.unmodifiableMap(routes);
    }

    protected void get(String url, EndPoint endPoint){
        doRegisterRoute(BASE_PATH + url,  HttpMethods.GET, endPoint);
    }
    protected void post(String url, EndPoint endPoint){
        doRegisterRoute(BASE_PATH + url,  HttpMethods.POST, endPoint);
    }
}
