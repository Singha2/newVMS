package vms.webservice.core;

import java.util.Map;

public class WebServiceConfig {

    private Map<String, Route> allRoutes;

    public WebServiceConfig() {
        this.allRoutes = new Router().provideAllRoutes();
    }


    public final EndPoint getEndPoint(String urlPattern){
        return allRoutes.get(urlPattern).getEndPoint();
    }

}
