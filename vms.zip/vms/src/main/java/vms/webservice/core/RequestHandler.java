package vms.webservice.core;

import com.google.gson.Gson;
import vms.dto.ResponseDTO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class RequestHandler {
    WebServiceConfig config;
    public RequestHandler(WebServiceConfig config) {
        this.config = config;
    }

    public void doHandle(HttpServletRequest req, HttpServletResponse res) throws IOException {

       String uri = req.getRequestURI();
        String method = req.getMethod();
        String uriIdentifier = method + "|" + uri;
        EndPoint endPoint = config.getEndPoint(uriIdentifier);
        ResponseDTO responseDTO = endPoint.process(req, res);
        res.setContentType("application/json");
        res.setCharacterEncoding("UTF-8");
        String json = new Gson().toJson(responseDTO);
        PrintWriter out =  res.getWriter();
        out.print(json);
        out.flush();
        out.close();

    }
}
