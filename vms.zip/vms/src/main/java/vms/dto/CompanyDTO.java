package vms.dto;

public class CompanyDTO extends ResponseDTO {
    public CompanyDTO() {
        super("success");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortname() {
        return shortname;
    }

    public void setShortname(String shortname) {
        this.shortname = shortname;
    }

    private String shortname;
    private String name;
}
