package vms;

import org.apache.catalina.Context;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.startup.Tomcat;
import vms.web.WSServlet;

import javax.servlet.ServletException;
import java.io.File;

public class Main {
    public static  void main(String args []) throws LifecycleException,
            InterruptedException, ServletException{
        String myArgs = null;
        String defaultPort = "6080";
        if(args.length > 0) {
            myArgs = args[0];
        }
        if(myArgs != null){
            defaultPort = myArgs.split("=")[1];
        }
        System.out.println(myArgs);
        Tomcat tomcat = new Tomcat();
        tomcat.setPort(Integer.parseInt(defaultPort));
        Context ctx = tomcat.addContext("/vms", new File(".").getAbsolutePath());
        tomcat.addServlet(ctx, "WSServlet", new WSServlet());
        ctx.addServletMappingDecoded("/rest/*", "WSServlet");

        tomcat.start();
        tomcat.getServer().await();
    }
}
